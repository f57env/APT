#!/bin/bash
# =============================================================================
# APT Detection Platform — Project Scaffold Script
# Run this from the directory where you want the project created.
# Usage: bash 01_scaffold_project.sh
# =============================================================================

set -e  # Exit on any error

PROJECT="apt-platform"
echo "🛡️  Creating APT Detection Platform project scaffold..."

# ── Root project directory ────────────────────────────────────────────────────
mkdir -p "$PROJECT"
cd "$PROJECT"

# ── Maven module directories ──────────────────────────────────────────────────
# Each module gets its own src/main/java and src/test/java tree
for module in core ingestion detection api response; do
  mkdir -p "$module/src/main/java/com/apt/$module"
  mkdir -p "$module/src/main/resources"
  mkdir -p "$module/src/test/java/com/apt/$module"
done

# ── Docker & config directories ───────────────────────────────────────────────
mkdir -p docker/init-scripts
mkdir -p config
mkdir -p scripts

# ── Frontend placeholder ──────────────────────────────────────────────────────
mkdir -p frontend/src

echo "✅  Directory structure created."
echo ""
echo "📁 Structure:"
find . -type d | sed 's|[^/]*/|  |g'

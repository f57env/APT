package com.apt.ingestion.consumer;

import com.apt.core.model.NetworkEvent;
import com.apt.ingestion.repository.NetworkEventRepository;
import com.apt.ingestion.service.EventNormalizationService;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.serializer.JsonSerializer;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.kafka.test.utils.KafkaTestUtils;
import org.springframework.test.annotation.DirtiesContext;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static org.awaitility.Awaitility.await;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * NetworkEventConsumerTest — verifies the consumer processes Kafka messages correctly.
 *
 * Uses @EmbeddedKafka — spins up a real in-memory Kafka broker for the test.
 * No Docker required. This is fast (~1s) and completely self-contained.
 *
 * We mock the repository so we don't need MongoDB running.
 * This is a true unit/slice test of the consumer logic only.
 *
 * @DirtiesContext — resets the Spring context after the test so the embedded
 * Kafka broker doesn't leak into other tests.
 */
@SpringBootTest
@EmbeddedKafka(
    partitions = 1,
    topics = {"network_traffic"},
    brokerProperties = {
        "listeners=PLAINTEXT://localhost:9099",
        "port=9099"
    }
)
@DirtiesContext
@DisplayName("NetworkEventConsumer")
class NetworkEventConsumerTest {

    @Autowired
    private EmbeddedKafkaBroker embeddedKafkaBroker;

    @MockBean
    private NetworkEventRepository eventRepository;

    @MockBean
    private EventNormalizationService normalizationService;

    private KafkaTemplate<String, NetworkEvent> testProducer;

    @BeforeEach
    void setUp() {
        // Configure a test producer pointing at the embedded broker
        Map<String, Object> producerProps =
            KafkaTestUtils.producerProps(embeddedKafkaBroker);
        producerProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        producerProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

        var producerFactory = new DefaultKafkaProducerFactory<String, NetworkEvent>(producerProps);
        testProducer = new KafkaTemplate<>(producerFactory);

        // Normalization service: return the event as-is (we test normalization separately)
        when(normalizationService.normalize(any())).thenAnswer(i -> i.getArgument(0));

        // Repository: simulate successful save
        when(eventRepository.save(any())).thenAnswer(i -> i.getArgument(0));
    }

    @Test
    @DisplayName("consumes a network event from Kafka and persists it to MongoDB")
    void consume_persistsEventToMongoDB() {
        // Arrange
        NetworkEvent event = NetworkEvent.builder()
            .id("test-event-001")
            .timestamp(Instant.now())
            .userId("alice.smith")
            .srcIp("192.168.1.100")
            .dstIp("10.0.0.5")
            .port(443)
            .bytes(50_000L)
            .protocol("TCP")
            .action("CONNECT")
            .eventSource(NetworkEvent.EventSource.SIMULATED)
            .build();

        // Act: publish the event to the embedded Kafka topic
        testProducer.send(new ProducerRecord<>("network_traffic", event.getUserId(), event));

        // Assert: wait up to 10 seconds for the consumer to process the message
        await()
            .atMost(10, TimeUnit.SECONDS)
            .untilAsserted(() -> {
                // Verify normalize was called with the event
                verify(normalizationService, atLeastOnce()).normalize(any());
                // Verify save was called — event reached MongoDB
                verify(eventRepository, atLeastOnce()).save(any());
            });
    }

    @Test
    @DisplayName("calls normalization before persisting")
    void consume_normalizesBeforePersisting() {
        NetworkEvent rawEvent = NetworkEvent.builder()
            .id("raw-event-002")
            .timestamp(Instant.now())
            .userId("CORP\\BOB.JONES")   // Non-normalized: has domain prefix
            .srcIp("::1")               // Non-normalized: IPv6 loopback
            .dstIp("10.0.0.1")
            .port(22)
            .bytes(500L)
            .protocol("6")             // Non-normalized: numeric protocol
            .action("AUTH_FAILURE")    // Non-normalized: raw action string
            .eventSource(NetworkEvent.EventSource.SIMULATED)
            .build();

        testProducer.send(new ProducerRecord<>("network_traffic", "bob", rawEvent));

        await()
            .atMost(10, TimeUnit.SECONDS)
            .untilAsserted(() -> {
                // normalization must happen BEFORE save — verify the order
                var inOrder = inOrder(normalizationService, eventRepository);
                inOrder.verify(normalizationService).normalize(any());
                inOrder.verify(eventRepository).save(any());
            });
    }
}

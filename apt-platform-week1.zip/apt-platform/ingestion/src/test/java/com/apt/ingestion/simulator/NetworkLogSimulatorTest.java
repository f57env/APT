package com.apt.ingestion.simulator;

import com.apt.core.model.NetworkEvent;
import com.apt.ingestion.repository.NetworkEventRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.TestPropertySource;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * NetworkLogSimulatorTest — verifies the log simulator produces well-formed events.
 *
 * We mock KafkaTemplate to capture produced events without needing Kafka running.
 * This keeps tests fast and focused on the simulator logic only.
 */
@SpringBootTest
@DirtiesContext
@TestPropertySource(properties = {
    "app.kafka.simulation.events-per-second=100",  // Fast for testing
    "app.kafka.simulation.apt-injection-rate=0.5"  // 50% APT — ensures we get some
})
@DisplayName("NetworkLogSimulator")
class NetworkLogSimulatorTest {

    @MockBean
    @SuppressWarnings("unchecked")
    private KafkaTemplate<String, NetworkEvent> kafkaTemplate;

    @MockBean
    private NetworkEventRepository eventRepository;

    @Autowired
    private NetworkLogSimulator simulator;

    @Test
    @DisplayName("produces events with all required fields populated")
    void produceEvent_allFieldsPopulated() {
        List<NetworkEvent> captured = new ArrayList<>();

        // Capture produced events via mock
        when(kafkaTemplate.send(anyString(), anyString(), any(NetworkEvent.class)))
            .thenAnswer(invocation -> {
                captured.add(invocation.getArgument(2));
                return CompletableFuture.completedFuture(null);
            });

        // Trigger several events
        for (int i = 0; i < 20; i++) {
            simulator.produceEvent();
        }

        assertThat(captured).hasSize(20);

        // Every event must have all required fields
        captured.forEach(event -> {
            assertThat(event.getUserId()).as("userId must not be null").isNotNull();
            assertThat(event.getTimestamp()).as("timestamp must not be null").isNotNull();
            assertThat(event.getSrcIp()).as("srcIp must not be null").isNotNull();
            assertThat(event.getDstIp()).as("dstIp must not be null").isNotNull();
            assertThat(event.getPort()).as("port must be valid").isBetween(0, 65535);
            assertThat(event.getBytes()).as("bytes must be non-negative").isGreaterThanOrEqualTo(0);
            assertThat(event.getProtocol()).as("protocol must not be null").isNotNull();
            assertThat(event.getAction()).as("action must not be null").isNotNull();
            assertThat(event.getEventSource())
                .as("eventSource must be SIMULATED")
                .isEqualTo(NetworkEvent.EventSource.SIMULATED);
        });
    }

    @Test
    @DisplayName("APT events use known indicator ports (445, 22, 3389)")
    void aptEvents_useKnownIndicatorPorts() {
        List<NetworkEvent> captured = new ArrayList<>();

        when(kafkaTemplate.send(anyString(), anyString(), any(NetworkEvent.class)))
            .thenAnswer(invocation -> {
                captured.add(invocation.getArgument(2));
                return CompletableFuture.completedFuture(null);
            });

        // With 50% APT injection, 200 events should give us plenty of APT events
        for (int i = 0; i < 200; i++) {
            simulator.produceEvent();
        }

        // Some events should use APT-indicator ports
        List<Integer> ports = captured.stream().map(NetworkEvent::getPort).toList();
        assertThat(ports).as("Should include SMB port 445 (lateral movement)")
            .contains(445);
        assertThat(ports).as("Should include SSH port 22 (brute force)")
            .contains(22);
        assertThat(ports).as("Should include RDP port 3389 (off-hours login)")
            .contains(3389);
    }

    @Test
    @DisplayName("APT events include FAILED_LOGIN actions (brute force indicator)")
    void aptEvents_includeFailedLoginActions() {
        List<NetworkEvent> captured = new ArrayList<>();

        when(kafkaTemplate.send(anyString(), anyString(), any(NetworkEvent.class)))
            .thenAnswer(invocation -> {
                captured.add(invocation.getArgument(2));
                return CompletableFuture.completedFuture(null);
            });

        for (int i = 0; i < 200; i++) {
            simulator.produceEvent();
        }

        long failedLogins = captured.stream()
            .filter(e -> "FAILED_LOGIN".equals(e.getAction()))
            .count();

        assertThat(failedLogins)
            .as("With 50% APT rate, should have multiple FAILED_LOGIN events")
            .isGreaterThan(5);
    }

    @Test
    @DisplayName("service account events target internal IPs (lateral movement pattern)")
    void serviceAccountEvents_targetInternalIps() {
        List<NetworkEvent> captured = new ArrayList<>();

        when(kafkaTemplate.send(anyString(), anyString(), any(NetworkEvent.class)))
            .thenAnswer(invocation -> {
                captured.add(invocation.getArgument(2));
                return CompletableFuture.completedFuture(null);
            });

        for (int i = 0; i < 200; i++) {
            simulator.produceEvent();
        }

        // svc_backup doing lateral movement should connect to internal IPs via SMB
        boolean hasLateralMovement = captured.stream()
            .anyMatch(e -> "svc_backup".equals(e.getUserId())
                       && e.getPort() == 445
                       && e.getDstIp().startsWith("10.") || (e.getDstIp() != null && e.getDstIp().startsWith("192.168.")));

        assertThat(hasLateralMovement)
            .as("svc_backup should show lateral movement via SMB to internal IPs")
            .isTrue();
    }
}

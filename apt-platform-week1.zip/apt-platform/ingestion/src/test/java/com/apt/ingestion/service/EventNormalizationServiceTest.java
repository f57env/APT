package com.apt.ingestion.service;

import com.apt.core.model.NetworkEvent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.time.Instant;

import static org.assertj.core.api.Assertions.*;

/**
 * EventNormalizationServiceTest — unit tests for the normalization layer.
 *
 * We use AssertJ (assertThat) rather than JUnit's assertEquals because:
 *   - Failure messages are more readable: "expected '0.0.0.0' but was '999.1.1.1'"
 *   - Fluent API allows chaining: assertThat(x).isNotNull().isEqualTo("y")
 *
 * These tests do NOT need Spring context (no @SpringBootTest) —
 * EventNormalizationService is pure logic with no dependencies.
 * This makes them run in ~50ms instead of ~5 seconds.
 */
class EventNormalizationServiceTest {

    private EventNormalizationService service;

    @BeforeEach
    void setUp() {
        service = new EventNormalizationService();
    }

    // ── Null / empty input ─────────────────────────────────────────────────────

    @Test
    @DisplayName("normalize() throws when given null event")
    void normalize_nullEvent_throwsIllegalArgument() {
        assertThatThrownBy(() -> service.normalize(null))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessageContaining("null");
    }

    // ── ID handling ───────────────────────────────────────────────────────────

    @Test
    @DisplayName("normalize() preserves existing ID")
    void normalize_existingId_preserved() {
        NetworkEvent event = buildValidEvent();
        event.setId("my-existing-id");

        NetworkEvent result = service.normalize(event);

        assertThat(result.getId()).isEqualTo("my-existing-id");
    }

    @Test
    @DisplayName("normalize() generates ID when missing")
    void normalize_missingId_generatesUUID() {
        NetworkEvent event = buildValidEvent();
        event.setId(null);

        NetworkEvent result = service.normalize(event);

        assertThat(result.getId()).isNotNull().isNotBlank();
    }

    // ── Timestamp handling ────────────────────────────────────────────────────

    @Test
    @DisplayName("normalize() backfills missing timestamp with current time")
    void normalize_nullTimestamp_backfilled() {
        NetworkEvent event = buildValidEvent();
        event.setTimestamp(null);
        Instant before = Instant.now();

        NetworkEvent result = service.normalize(event);

        assertThat(result.getTimestamp())
            .isAfterOrEqualTo(before)
            .isBeforeOrEqualTo(Instant.now());
    }

    @Test
    @DisplayName("normalize() rejects far-future timestamp and backfills")
    void normalize_futureTimestamp_backfilled() {
        NetworkEvent event = buildValidEvent();
        event.setTimestamp(Instant.now().plusSeconds(7200)); // 2 hours in future

        NetworkEvent result = service.normalize(event);

        assertThat(result.getTimestamp()).isBeforeOrEqualTo(Instant.now().plusSeconds(5));
    }

    @Test
    @DisplayName("normalize() preserves valid timestamp")
    void normalize_validTimestamp_preserved() {
        Instant ts = Instant.parse("2024-06-15T09:30:00Z");
        NetworkEvent event = buildValidEvent();
        event.setTimestamp(ts);

        NetworkEvent result = service.normalize(event);

        assertThat(result.getTimestamp()).isEqualTo(ts);
    }

    // ── User ID handling ──────────────────────────────────────────────────────

    @Test
    @DisplayName("normalize() trims and lowercases userId")
    void normalize_userIdCasing_normalized() {
        NetworkEvent event = buildValidEvent();
        event.setUserId("  Alice.Smith  ");

        NetworkEvent result = service.normalize(event);

        assertThat(result.getUserId()).isEqualTo("alice.smith");
    }

    @Test
    @DisplayName("normalize() defaults blank userId to 'anonymous'")
    void normalize_blankUserId_defaultsToAnonymous() {
        NetworkEvent event = buildValidEvent();
        event.setUserId("   ");

        NetworkEvent result = service.normalize(event);

        assertThat(result.getUserId()).isEqualTo("anonymous");
    }

    // ── IP address handling ───────────────────────────────────────────────────

    @Nested
    @DisplayName("IP address normalization")
    class IpNormalizationTests {

        @Test
        @DisplayName("normalize() preserves valid IPv4")
        void validIp_preserved() {
            NetworkEvent event = buildValidEvent();
            event.setSrcIp("192.168.1.100");

            NetworkEvent result = service.normalize(event);

            assertThat(result.getSrcIp()).isEqualTo("192.168.1.100");
        }

        @Test
        @DisplayName("normalize() replaces invalid IP with 0.0.0.0")
        void invalidIp_replaced() {
            NetworkEvent event = buildValidEvent();
            event.setSrcIp("999.1.1.1");

            NetworkEvent result = service.normalize(event);

            assertThat(result.getSrcIp()).isEqualTo("0.0.0.0");
        }

        @Test
        @DisplayName("normalize() replaces null IP with 0.0.0.0")
        void nullIp_replaced() {
            NetworkEvent event = buildValidEvent();
            event.setDstIp(null);

            NetworkEvent result = service.normalize(event);

            assertThat(result.getDstIp()).isEqualTo("0.0.0.0");
        }
    }

    // ── Port validation ───────────────────────────────────────────────────────

    @Test
    @DisplayName("normalize() clamps negative port to 0")
    void negativePort_clampedToZero() {
        NetworkEvent event = buildValidEvent();
        event.setPort(-1);

        NetworkEvent result = service.normalize(event);

        assertThat(result.getPort()).isZero();
    }

    @Test
    @DisplayName("normalize() clamps port above 65535 to 0")
    void overflowPort_clampedToZero() {
        NetworkEvent event = buildValidEvent();
        event.setPort(99999);

        NetworkEvent result = service.normalize(event);

        assertThat(result.getPort()).isZero();
    }

    // ── String field normalization ────────────────────────────────────────────

    @Test
    @DisplayName("normalize() uppercases protocol and action")
    void stringFields_uppercased() {
        NetworkEvent event = buildValidEvent();
        event.setProtocol("tcp");
        event.setAction("connect");

        NetworkEvent result = service.normalize(event);

        assertThat(result.getProtocol()).isEqualTo("TCP");
        assertThat(result.getAction()).isEqualTo("CONNECT");
    }

    @Test
    @DisplayName("normalize() defaults null protocol to UNKNOWN")
    void nullProtocol_defaultsToUnknown() {
        NetworkEvent event = buildValidEvent();
        event.setProtocol(null);

        NetworkEvent result = service.normalize(event);

        assertThat(result.getProtocol()).isEqualTo("UNKNOWN");
    }

    // ── High-risk port detection ──────────────────────────────────────────────

    @Test
    @DisplayName("isHighRiskPort() returns true for SMB port 445")
    void highRiskPort_smb() {
        assertThat(service.isHighRiskPort(445)).isTrue();
    }

    @Test
    @DisplayName("isHighRiskPort() returns false for HTTPS port 443")
    void normalPort_notHighRisk() {
        assertThat(service.isHighRiskPort(443)).isFalse();
    }

    // ── Internal IP detection ─────────────────────────────────────────────────

    @Test
    @DisplayName("isInternalDestination() returns true for RFC 1918 address")
    void internalIp_detected() {
        assertThat(service.isInternalDestination("10.0.1.5")).isTrue();
        assertThat(service.isInternalDestination("192.168.1.100")).isTrue();
        assertThat(service.isInternalDestination("172.16.0.1")).isTrue();
    }

    @Test
    @DisplayName("isInternalDestination() returns false for public IP")
    void externalIp_notInternal() {
        assertThat(service.isInternalDestination("8.8.8.8")).isFalse();
        assertThat(service.isInternalDestination("104.18.23.54")).isFalse();
    }

    // ── Negative bytes ────────────────────────────────────────────────────────

    @Test
    @DisplayName("normalize() sets negative bytes to 0")
    void negativeBytes_clampedToZero() {
        NetworkEvent event = buildValidEvent();
        event.setBytes(-100);

        NetworkEvent result = service.normalize(event);

        assertThat(result.getBytes()).isZero();
    }

    // ── Builder helper ─────────────────────────────────────────────────────────

    private NetworkEvent buildValidEvent() {
        return NetworkEvent.builder()
            .id("test-id-123")
            .timestamp(Instant.now())
            .userId("alice.smith")
            .srcIp("192.168.1.100")
            .dstIp("10.0.0.5")
            .port(443)
            .bytes(50_000)
            .protocol("TCP")
            .action("CONNECT")
            .hostname("alice-laptop.corp.internal")
            .processName("chrome.exe")
            .eventSource(NetworkEvent.EventSource.SIMULATED)
            .build();
    }
}

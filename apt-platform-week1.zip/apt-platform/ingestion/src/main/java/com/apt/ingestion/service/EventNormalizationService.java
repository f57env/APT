package com.apt.ingestion.service;

import com.apt.core.model.NetworkEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * EventNormalizationService — cleans, validates, and enriches raw network events
 * before they are stored in MongoDB.
 *
 * Why normalize?
 * Real log sources (Sysmon, auditd, pcap) have inconsistent formats:
 *   - Some timestamps are epoch millis, others are ISO strings
 *   - IPs may include port suffixes ("10.0.1.5:52341")
 *   - Actions may be "conn", "CONNECT", "connection" from different sources
 *   - Missing fields need safe defaults so the ML engine doesn't NPE
 *
 * This service is the "data quality gate" — nothing dirty reaches MongoDB.
 */
@Slf4j
@Service
public class EventNormalizationService {

    private static final Set<String> INTERNAL_PREFIXES = Set.of(
        "10.", "192.168.", "172.16.", "172.17.", "172.18.", "172.19.",
        "172.20.", "172.21.", "172.22.", "172.23.", "172.24.", "172.25.",
        "172.26.", "172.27.", "172.28.", "172.29.", "172.30.", "172.31."
    );

    private static final Pattern IP_WITH_PORT = Pattern.compile("^(\\d+\\.\\d+\\.\\d+\\.\\d+):\\d+$");
    private static final Pattern VALID_IP     = Pattern.compile("^\\d{1,3}(\\.\\d{1,3}){3}$");

    public NetworkEvent normalize(NetworkEvent raw) {
        if (raw == null) throw new IllegalArgumentException("Cannot normalize a null event");

        return NetworkEvent.builder()
            .id(ensureId(raw.getId()))
            .timestamp(ensureTimestamp(raw.getTimestamp()))
            .userId(normalizeUserId(raw.getUserId()))
            .srcIp(normalizeIp(raw.getSrcIp()))
            .dstIp(normalizeIp(raw.getDstIp()))
            .port(normalizePort(raw.getPort()))
            .bytes(normalizeBytes(raw.getBytes()))
            .protocol(normalizeProtocol(raw.getProtocol()))
            .action(normalizeAction(raw.getAction()))
            .hostname(raw.getHostname() != null ? raw.getHostname().toLowerCase() : "unknown")
            .processName(raw.getProcessName() != null ? raw.getProcessName().toLowerCase() : "unknown")
            .eventSource(raw.getEventSource() != null ? raw.getEventSource() : NetworkEvent.EventSource.SIMULATED)
            .build();
    }

    private String ensureId(String id) {
        return (id != null && !id.isBlank()) ? id : UUID.randomUUID().toString();
    }

    private Instant ensureTimestamp(Instant ts) {
        if (ts == null) return Instant.now();
        Instant now = Instant.now();
        // Reject timestamps >5 minutes in the future (clock skew / replay attack)
        if (ts.isAfter(now.plusSeconds(300))) {
            log.warn("Future timestamp detected ({}), replacing with now", ts);
            return now;
        }
        return ts;
    }

    private String normalizeUserId(String userId) {
        if (userId == null || userId.isBlank()) return "anonymous";
        // Lowercase, trim, strip domain prefix: "CORP\\alice" → "alice"
        String cleaned = userId.trim().toLowerCase();
        int backslash = cleaned.lastIndexOf('\\');
        return backslash >= 0 ? cleaned.substring(backslash + 1) : cleaned;
    }

    private String normalizeIp(String ip) {
        if (ip == null || ip.isBlank()) return "0.0.0.0";
        // Strip port suffix if present: "10.0.1.5:52341" → "10.0.1.5"
        var matcher = IP_WITH_PORT.matcher(ip.trim());
        String cleaned = matcher.matches() ? matcher.group(1) : ip.trim();
        if (!VALID_IP.matcher(cleaned).matches()) {
            log.debug("Non-standard or invalid IP format '{}', replacing with 0.0.0.0", cleaned);
            return "0.0.0.0";
        }
        // Validate each octet is 0–255
        String[] octets = cleaned.split("\\.");
        for (String octet : octets) {
            int val = Integer.parseInt(octet);
            if (val < 0 || val > 255) return "0.0.0.0";
        }
        return cleaned;
    }

    private int normalizePort(int port) {
        return Math.max(0, Math.min(65535, port));
    }

    private long normalizeBytes(long bytes) {
        return Math.max(0, bytes);
    }

    private String normalizeProtocol(String protocol) {
        if (protocol == null || protocol.isBlank()) return "UNKNOWN";
        return switch (protocol.trim().toUpperCase()) {
            case "TCP", "6"  -> "TCP";
            case "UDP", "17" -> "UDP";
            case "ICMP", "1" -> "ICMP";
            default          -> protocol.trim().toUpperCase();
        };
    }

    private String normalizeAction(String action) {
        if (action == null || action.isBlank()) return "UNKNOWN";
        return switch (action.trim().toUpperCase()) {
            case "CONN", "CONNECT", "CONNECTION", "SYN"    -> "CONNECT";
            case "SEND", "WRITE", "UPLOAD", "PUT"          -> "SEND";
            case "RECV", "RECEIVE", "READ", "DOWNLOAD"     -> "RECEIVE";
            case "FAILED_LOGIN", "AUTH_FAIL", "LOGON_FAIL" -> "FAILED_LOGIN";
            case "LOGIN", "LOGON", "AUTH_SUCCESS"          -> "LOGIN";
            case "LOGOUT", "LOGOFF", "DISCONNECT"          -> "LOGOUT";
            default                                         -> action.trim().toUpperCase();
        };
    }

    /** True for RFC-1918 private / loopback / link-local addresses */
    public static boolean isInternalIp(String ip) {
        if (ip == null) return false;
        return INTERNAL_PREFIXES.stream().anyMatch(ip::startsWith)
            || ip.startsWith("127.")
            || ip.startsWith("169.254.");
    }

    /**
     * Instance method alias used by tests and detection engine.
     * Checks if a destination IP is on the internal corporate network.
     */
    public boolean isInternalDestination(String ip) {
        return isInternalIp(ip);
    }

    // Well-known high-risk ports: common lateral movement and C2 channels
    private static final Set<Integer> HIGH_RISK_PORTS = Set.of(
        445,   // SMB — lateral movement (T1021)
        135,   // RPC — DCOM exploitation
        139,   // NetBIOS — legacy SMB
        3389,  // RDP — remote desktop (T1021.001)
        5985,  // WinRM HTTP — remote management
        5986,  // WinRM HTTPS
        4444,  // Metasploit default reverse shell
        1337,  // Common C2 port
        6666,  // Common C2 port
        9999   // Common C2 port
    );

    /**
     * Returns true if the port is commonly associated with lateral movement,
     * C2 channels, or exploitation frameworks.
     * High-risk port alone doesn't trigger an alert — it adds weight to the score.
     */
    public boolean isHighRiskPort(int port) {
        return HIGH_RISK_PORTS.contains(port);
    }
}

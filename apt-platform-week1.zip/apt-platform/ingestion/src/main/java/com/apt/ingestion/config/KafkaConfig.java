package com.apt.ingestion.config;

import com.apt.core.model.NetworkEvent;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.*;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.kafka.support.serializer.JsonSerializer;

import java.util.HashMap;
import java.util.Map;

/**
 * KafkaConfig — configures producers and consumers for the ingestion pipeline.
 *
 * Key decisions explained:
 *
 * 1. MANUAL_IMMEDIATE acknowledgment mode:
 *    The consumer manually calls ack.acknowledge() only after a successful
 *    MongoDB write. If the app crashes before acking, Kafka re-delivers.
 *    This prevents data loss at the cost of possible duplicate processing
 *    (which we handle with MongoDB's upsert on event ID).
 *
 * 2. Concurrency = 3:
 *    The listener container spawns 3 threads, each processing one Kafka
 *    partition. This allows parallel ingestion without Kafka partition
 *    ordering being broken (each thread handles its own partition).
 *
 * 3. Trusted packages:
 *    Jackson deserializer needs to know which classes are safe to
 *    instantiate from JSON. Restricting to our own packages prevents
 *    deserialization attacks.
 */
@Configuration
public class KafkaConfig {

    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;

    // ── Producer (Log Simulator) ──────────────────────────────────────────────

    @Bean
    public ProducerFactory<String, NetworkEvent> producerFactory() {
        Map<String, Object> config = new HashMap<>();
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

        // Delivery guarantees: wait for all replicas to acknowledge
        config.put(ProducerConfig.ACKS_CONFIG, "all");

        // Retry on transient failures (network blip etc.)
        config.put(ProducerConfig.RETRIES_CONFIG, 3);

        // Batch small messages to reduce network round-trips (16KB batches)
        config.put(ProducerConfig.BATCH_SIZE_CONFIG, 16384);

        // Wait up to 5ms to fill a batch before sending
        config.put(ProducerConfig.LINGER_MS_CONFIG, 5);

        return new DefaultKafkaProducerFactory<>(config);
    }

    @Bean
    public KafkaTemplate<String, NetworkEvent> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }

    // ── Consumer (Ingestion Pipeline) ─────────────────────────────────────────

    @Bean
    public ConsumerFactory<String, NetworkEvent> consumerFactory() {
        JsonDeserializer<NetworkEvent> deserializer = new JsonDeserializer<>(NetworkEvent.class);
        // Only trust our own package — prevents deserialization attacks
        deserializer.addTrustedPackages("com.apt.core.model");
        deserializer.setUseTypeMapperForKey(false);

        Map<String, Object> config = new HashMap<>();
        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        config.put(ConsumerConfig.GROUP_ID_CONFIG, "apt-detection-group");
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, deserializer);
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

        // Do NOT auto-commit — we commit manually after successful MongoDB write
        config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);

        // Fetch up to 50 records per poll — tunable for throughput vs latency
        config.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, 50);

        return new DefaultKafkaConsumerFactory<>(config,
            new StringDeserializer(), deserializer);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, NetworkEvent>
            kafkaListenerContainerFactory() {

        ConcurrentKafkaListenerContainerFactory<String, NetworkEvent> factory =
            new ConcurrentKafkaListenerContainerFactory<>();

        factory.setConsumerFactory(consumerFactory());

        // Manual acknowledgment — commit offset only after successful processing
        factory.getContainerProperties().setAckMode(
            ContainerProperties.AckMode.MANUAL_IMMEDIATE
        );

        // 3 concurrent threads = processes up to 3 partitions in parallel
        factory.setConcurrency(3);

        // Retry failed records up to 3 times before sending to dead-letter topic
        factory.setCommonErrorHandler(new org.springframework.kafka.listener
            .DefaultErrorHandler(new org.springframework.util.backoff.FixedBackOff(1000L, 3)));

        return factory;
    }
}

package com.apt.ingestion.consumer;

import com.apt.core.model.NetworkEvent;
import com.apt.ingestion.repository.NetworkEventRepository;
import com.apt.ingestion.service.EventNormalizationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

/**
 * NetworkEventConsumer — the ingestion pipeline's write side.
 *
 * Flow:
 *   Kafka topic "network_traffic"
 *     → normalize (clean, enrich, validate)
 *     → persist to MongoDB
 *     → publish internal Spring event for the detection engine to pick up
 *
 * Why manual acknowledgment (AckMode.MANUAL_IMMEDIATE)?
 * Default auto-ack acknowledges the offset before we've persisted the event.
 * If the app crashes mid-write, we'd lose that event.
 * With manual ack, we only commit the offset AFTER a successful MongoDB write,
 * so on restart Kafka re-delivers any unconfirmed messages.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class NetworkEventConsumer {

    private final NetworkEventRepository eventRepository;
    private final EventNormalizationService normalizationService;

    @KafkaListener(
        topics = "${app.kafka.topics.network-traffic}",
        groupId = "${spring.kafka.consumer.group-id}",
        containerFactory = "kafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, NetworkEvent> record, Acknowledgment ack) {
        try {
            NetworkEvent raw = record.value();
            log.debug("Received event from Kafka: partition={} offset={} userId={}",
                record.partition(), record.offset(), raw.getUserId());

            // Step 1: Normalize — clean IPs, standardize fields, enrich with context
            NetworkEvent normalized = normalizationService.normalize(raw);

            // Step 2: Persist to MongoDB
            NetworkEvent saved = eventRepository.save(normalized);
            log.debug("Persisted event {} for user {}", saved.getId(), saved.getUserId());

            // Step 3: Acknowledge offset — only AFTER successful write
            ack.acknowledge();

        } catch (Exception e) {
            log.error("Failed to process Kafka record at offset {}: {}",
                record.offset(), e.getMessage(), e);
            // Do NOT acknowledge — Kafka will re-deliver this message
            // In production, after N retries this goes to a Dead Letter Topic
        }
    }
}

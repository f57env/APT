package com.apt.ingestion.simulator;

import com.apt.core.model.NetworkEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalTime;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * NetworkLogSimulator — generates realistic network events for development/testing.
 *
 * It produces two types of events:
 *
 * 1. NORMAL events — typical business-hours traffic:
 *    - HTTP/HTTPS to internal services
 *    - Small-to-medium data transfers
 *    - Standard user work patterns (9AM–6PM, familiar IPs)
 *
 * 2. APT-PATTERN events — injected at configurable rate:
 *    - Lateral movement via SMB (port 445) to internal hosts
 *    - Large data transfers at unusual hours (3AM)
 *    - Failed login spikes (brute force T1110)
 *    - DNS queries to unusual external domains (C2 T1071)
 *    - Service account accessing user-type resources
 *
 * Why simulate rather than capture real traffic?
 * In dev, we don't have a live network. The simulator lets us:
 *   - Control the ratio of normal:malicious events
 *   - Reproduce specific APT scenarios deterministically for testing
 *   - Run the full pipeline without network hardware
 *
 * In production, replace this with Pcap4j packet capture or
 * a real SIEM/EDR integration.
 */
@Slf4j
@Component
@EnableScheduling
@RequiredArgsConstructor
public class NetworkLogSimulator {

    private final KafkaTemplate<String, NetworkEvent> kafkaTemplate;

    @Value("${app.kafka.topics.network-traffic}")
    private String topic;

    @Value("${app.kafka.simulation.events-per-second:10}")
    private int eventsPerSecond;

    @Value("${app.kafka.simulation.apt-injection-rate:0.05}")
    private double aptInjectionRate;

    private final Random random = new Random();

    // Simulated users (service accounts are high-value APT targets)
    private static final List<String> USERS = List.of(
        "alice.smith", "bob.jones", "carol.white",
        "svc_backup", "svc_monitoring", "svc_deploy"   // Service accounts
    );

    // Internal IP ranges (simulated corporate network)
    private static final List<String> INTERNAL_IPS = List.of(
        "10.0.1.10", "10.0.1.11", "10.0.2.5", "10.0.2.20",
        "192.168.1.100", "192.168.1.101", "192.168.2.50"
    );

    // External IPs — some legitimate CDNs, some simulated C2 servers
    private static final List<String> EXTERNAL_IPS = List.of(
        "104.18.23.54",   // Cloudflare CDN (normal)
        "52.86.14.7",     // AWS (normal)
        "185.220.101.5",  // Simulated Tor exit node (suspicious)
        "91.108.4.15"     // Simulated C2 server (very suspicious)
    );

    /**
     * Fires at a fixed rate — produces N events per second.
     * fixedDelay = 1000ms / eventsPerSecond converted in the method.
     */
    @Scheduled(fixedDelayString = "#{1000 / ${app.kafka.simulation.events-per-second:10}}")
    public void produceEvent() {
        NetworkEvent event = random.nextDouble() < aptInjectionRate
                ? buildAptEvent()
                : buildNormalEvent();

        // Kafka key = userId: ensures all events for a user go to the same partition
        // This is critical for ordered processing in the detection engine
        kafkaTemplate.send(topic, event.getUserId(), event)
            .whenComplete((result, ex) -> {
                if (ex != null) {
                    log.error("Failed to produce event for user {}: {}", event.getUserId(), ex.getMessage());
                } else {
                    log.debug("Produced event: user={} port={} bytes={}",
                        event.getUserId(), event.getPort(), event.getBytes());
                }
            });
    }

    // ── Normal Event Builder ──────────────────────────────────────────────────

    private NetworkEvent buildNormalEvent() {
        String userId = randomFrom(USERS);
        boolean isServiceAccount = userId.startsWith("svc_");

        return NetworkEvent.builder()
            .id(UUID.randomUUID().toString())
            .timestamp(Instant.now())
            .userId(userId)
            .srcIp(randomFrom(INTERNAL_IPS))
            .dstIp(isServiceAccount ? randomFrom(INTERNAL_IPS) : randomFrom(EXTERNAL_IPS))
            .port(randomNormalPort())
            .bytes(normalBytes())
            .protocol("TCP")
            .action(randomNormalAction())
            .hostname(userId.replace(".", "-") + ".corp.internal")
            .processName(randomNormalProcess())
            .eventSource(NetworkEvent.EventSource.SIMULATED)
            .build();
    }

    // ── APT Event Builders ────────────────────────────────────────────────────
    // Each method simulates a specific MITRE ATT&CK technique

    private NetworkEvent buildAptEvent() {
        // Pick a random APT scenario
        return switch (random.nextInt(5)) {
            case 0 -> buildLateralMovementEvent();     // T1021 — Remote Services (SMB)
            case 1 -> buildBruteForceEvent();           // T1110 — Brute Force
            case 2 -> buildDataExfiltrationEvent();     // T1041 — Exfiltration over C2
            case 3 -> buildOffHoursLoginEvent();        // T1078 — Valid Accounts
            default -> buildC2BeaconEvent();            // T1071 — Application Layer C2
        };
    }

    /** T1021 — Lateral Movement via SMB (port 445) */
    private NetworkEvent buildLateralMovementEvent() {
        // APT pattern: service account connecting to many internal hosts via SMB
        return NetworkEvent.builder()
            .id(UUID.randomUUID().toString())
            .timestamp(Instant.now())
            .userId("svc_backup")                    // Compromised service account
            .srcIp("10.0.1.10")
            .dstIp(randomFrom(INTERNAL_IPS))
            .port(445)                               // SMB — classic lateral movement indicator
            .bytes(random.nextLong(500_000, 5_000_000))
            .protocol("TCP")
            .action("CONNECT")
            .hostname("svc-backup.corp.internal")
            .processName("psexec.exe")               // Common lateral movement tool
            .eventSource(NetworkEvent.EventSource.SIMULATED)
            .build();
    }

    /** T1110 — Brute Force: rapid failed logins */
    private NetworkEvent buildBruteForceEvent() {
        return NetworkEvent.builder()
            .id(UUID.randomUUID().toString())
            .timestamp(Instant.now())
            .userId(randomFrom(USERS))
            .srcIp("185.220.101.5")                 // External suspicious IP
            .dstIp("10.0.1.10")
            .port(22)                               // SSH brute force
            .bytes(random.nextLong(200, 1000))
            .protocol("TCP")
            .action("FAILED_LOGIN")                 // Key indicator
            .hostname("unknown-external")
            .processName("sshd")
            .eventSource(NetworkEvent.EventSource.SIMULATED)
            .build();
    }

    /** T1041 — Exfiltration: large upload to external IP at night */
    private NetworkEvent buildDataExfiltrationEvent() {
        return NetworkEvent.builder()
            .id(UUID.randomUUID().toString())
            // Simulate an event at 3AM — highly anomalous for most users
            .timestamp(Instant.now())
            .userId("alice.smith")
            .srcIp("192.168.1.100")
            .dstIp("91.108.4.15")                   // Suspicious external IP
            .port(443)                              // Blends with normal HTTPS
            .bytes(random.nextLong(50_000_000, 500_000_000))   // 50MB–500MB upload
            .protocol("TCP")
            .action("SEND")
            .hostname("alice-laptop.corp.internal")
            .processName("curl.exe")
            .eventSource(NetworkEvent.EventSource.SIMULATED)
            .build();
    }

    /** T1078 — Valid Accounts: legitimate credentials used at unusual hours */
    private NetworkEvent buildOffHoursLoginEvent() {
        return NetworkEvent.builder()
            .id(UUID.randomUUID().toString())
            .timestamp(Instant.now())
            .userId("bob.jones")
            .srcIp("185.220.101.5")                 // External IP (not Bob's usual location)
            .dstIp("10.0.2.5")
            .port(3389)                             // RDP — remote desktop
            .bytes(random.nextLong(10_000, 100_000))
            .protocol("TCP")
            .action("LOGIN")
            .hostname("unknown-external")
            .processName("mstsc.exe")
            .eventSource(NetworkEvent.EventSource.SIMULATED)
            .build();
    }

    /** T1071 — C2 Beaconing: regular small HTTP calls to suspicious domain */
    private NetworkEvent buildC2BeaconEvent() {
        return NetworkEvent.builder()
            .id(UUID.randomUUID().toString())
            .timestamp(Instant.now())
            .userId("svc_monitoring")               // Compromised monitoring service
            .srcIp("10.0.2.20")
            .dstIp("91.108.4.15")                   // Simulated C2 server
            .port(80)                               // Plain HTTP (unusual for legit traffic)
            .bytes(random.nextLong(100, 2000))      // Very small — beacon ping
            .protocol("TCP")
            .action("CONNECT")
            .hostname("monitor-01.corp.internal")
            .processName("java.exe")               // Process masquerading as legitimate
            .eventSource(NetworkEvent.EventSource.SIMULATED)
            .build();
    }

    // ── Helper methods ────────────────────────────────────────────────────────

    private int randomNormalPort() {
        return switch (random.nextInt(5)) {
            case 0 -> 443;   // HTTPS
            case 1 -> 80;    // HTTP
            case 2 -> 8080;  // Internal app
            case 3 -> 8443;  // Internal HTTPS
            default -> 22;   // SSH (legitimate admin use)
        };
    }

    private long normalBytes() {
        // Business data: 1KB to 10MB — right-skewed distribution
        return (long) (Math.abs(random.nextGaussian()) * 500_000 + 10_000);
    }

    private String randomNormalAction() {
        return switch (random.nextInt(4)) {
            case 0 -> "CONNECT";
            case 1 -> "SEND";
            case 2 -> "RECEIVE";
            default -> "CONNECT";
        };
    }

    private String randomNormalProcess() {
        return switch (random.nextInt(5)) {
            case 0 -> "chrome.exe";
            case 1 -> "outlook.exe";
            case 2 -> "java.exe";
            case 3 -> "node.exe";
            default -> "python.exe";
        };
    }

    private <T> T randomFrom(List<T> list) {
        return list.get(random.nextInt(list.size()));
    }
}

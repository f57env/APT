package com.apt.ingestion.repository;

import com.apt.core.model.NetworkEvent;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;

/**
 * NetworkEventRepository — MongoDB data access for raw network events.
 *
 * Spring Data MongoDB auto-implements all these methods from their names.
 * No SQL or query strings needed — Spring generates the MongoDB queries.
 *
 * Used by:
 *   - NetworkEventConsumer (write path: save raw events)
 *   - Detection engine (read path: load events for baseline building)
 *   - API layer (read path: event history for timeline "Story Mode")
 */
@Repository
public interface NetworkEventRepository extends MongoRepository<NetworkEvent, String> {

    /**
     * Find all events for a specific user, ordered by time descending.
     * Used to build UEBA behavioral profiles.
     * Example: "show me alice's last 1000 events"
     */
    List<NetworkEvent> findByUserIdOrderByTimestampDesc(String userId, Pageable pageable);

    /**
     * Find events for a user within a time window.
     * Used for: "what did alice do between midnight and 6AM?"
     */
    List<NetworkEvent> findByUserIdAndTimestampBetweenOrderByTimestampAsc(
        String userId, Instant start, Instant end
    );

    /**
     * Find recent events for multiple users (peer-group comparison).
     * Used by the detection engine to compare an entity against peers.
     */
    @Query("{ 'userId': { $in: ?0 }, 'timestamp': { $gte: ?1 } }")
    List<NetworkEvent> findRecentEventsForUsers(List<String> userIds, Instant since);

    /**
     * Find all events to/from a specific IP address.
     * Used in the forensic timeline to trace an attacker's path.
     */
    @Query("{ $or: [{ 'srcIp': ?0 }, { 'dstIp': ?0 }] }")
    List<NetworkEvent> findByIpAddress(String ipAddress, Pageable pageable);

    /**
     * Find high-volume events (potential data exfiltration).
     * bytes > threshold AND timestamp in range.
     */
    @Query("{ 'userId': ?0, 'bytes': { $gt: ?1 }, 'timestamp': { $gte: ?2 } }")
    List<NetworkEvent> findLargeTransfersByUser(String userId, long bytesThreshold, Instant since);

    /**
     * Find failed login events for a user in a time window.
     * Rapid failures = brute force (T1110).
     */
    List<NetworkEvent> findByUserIdAndActionAndTimestampBetween(
        String userId, String action, Instant start, Instant end
    );

    /** Count events for a user in a time window — used for rate-based features */
    long countByUserIdAndTimestampBetween(String userId, Instant start, Instant end);

    /** Count failed logins — key brute force indicator */
    long countByUserIdAndActionAndTimestampBetween(
        String userId, String action, Instant start, Instant end
    );

    /** Find events on high-risk ports */
    Page<NetworkEvent> findByPortInAndTimestampAfter(
        List<Integer> ports, Instant since, Pageable pageable
    );
}

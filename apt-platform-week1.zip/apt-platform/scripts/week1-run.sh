#!/bin/bash
# =============================================================================
# Week 1 — Full Setup & Verification Script
#
# This script:
#   1. Verifies prerequisites (Java 21, Maven, Docker)
#   2. Creates your .env file from the example
#   3. Starts the Docker Compose stack
#   4. Verifies all services are healthy
#   5. Compiles the project
#   6. Runs the unit tests
#   7. Starts the Spring Boot app
#
# Usage (from the apt-platform/ directory):
#   bash scripts/week1-run.sh
# =============================================================================

set -euo pipefail

# ── Colors for output ─────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; NC='\033[0m'

info()    { echo -e "${BLUE}ℹ️  $1${NC}"; }
success() { echo -e "${GREEN}✅ $1${NC}"; }
warn()    { echo -e "${YELLOW}⚠️  $1${NC}"; }
error()   { echo -e "${RED}❌ $1${NC}"; exit 1; }

echo ""
echo -e "${BLUE}🛡️  APT Detection Platform — Week 1 Setup${NC}"
echo "============================================"
echo ""

# ── Step 1: Check prerequisites ───────────────────────────────────────────────
info "Checking prerequisites..."

# Java 21+
if ! command -v java &>/dev/null; then
    error "Java not found. Install Temurin 21: sudo apt install temurin-21-jdk"
fi
JAVA_VER=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}' | cut -d. -f1)
if [ "$JAVA_VER" -lt 21 ]; then
    error "Java 21+ required. Found: Java $JAVA_VER"
fi
success "Java $JAVA_VER found"

# Maven
if ! command -v mvn &>/dev/null; then
    error "Maven not found. Install: sudo apt install maven"
fi
success "Maven $(mvn -version 2>&1 | head -1 | awk '{print $3}') found"

# Docker
if ! command -v docker &>/dev/null; then
    error "Docker not found. Install Docker Desktop and enable WSL integration."
fi
if ! docker info &>/dev/null; then
    error "Docker daemon is not running. Start Docker Desktop on Windows."
fi
success "Docker $(docker --version | awk '{print $3}' | tr -d ',') running"

# Docker Compose v2
if ! docker compose version &>/dev/null; then
    error "Docker Compose v2 not found. Update Docker Desktop."
fi
success "Docker Compose v2 found"

# ── Step 2: Create .env if it doesn't exist ───────────────────────────────────
echo ""
info "Checking .env file..."

if [ ! -f .env ]; then
    warn ".env not found — creating from .env.example with dev defaults"
    cp .env.example .env

    # Generate random secrets for local dev (not production-grade — just functional)
    JWT_SECRET=$(openssl rand -base64 48 2>/dev/null || cat /dev/urandom | tr -dc 'a-zA-Z0-9' | head -c 64)
    JASYPT_PWD=$(openssl rand -base64 24 2>/dev/null || cat /dev/urandom | tr -dc 'a-zA-Z0-9' | head -c 32)

    # Replace placeholders in .env
    sed -i "s|REPLACE_WITH_A_VERY_LONG_RANDOM_SECRET_STRING_AT_LEAST_256_BITS|${JWT_SECRET}|g" .env
    sed -i "s|REPLACE_WITH_JASYPT_PASSWORD|${JASYPT_PWD}|g" .env

    success ".env created with generated secrets"
    warn "Review .env before using in any shared or production environment"
else
    success ".env already exists"
fi

# ── Step 3: Start Docker Compose stack ───────────────────────────────────────
echo ""
info "Starting Docker Compose stack..."
docker compose up -d

# ── Step 4: Wait for services to be healthy ───────────────────────────────────
echo ""
info "Waiting for services to be healthy (up to 90 seconds)..."

wait_healthy() {
    local service=$1
    local max_attempts=18
    local attempt=0

    while [ $attempt -lt $max_attempts ]; do
        STATUS=$(docker compose ps "$service" --format json 2>/dev/null \
                 | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('Health','unknown'))" 2>/dev/null \
                 || echo "unknown")

        if [[ "$STATUS" == "healthy" ]]; then
            success "$service is healthy"
            return 0
        fi
        attempt=$((attempt + 1))
        echo -n "."
        sleep 5
    done
    error "$service did not become healthy in time. Check: docker compose logs $service"
}

wait_healthy "apt-zookeeper"
wait_healthy "apt-kafka"
wait_healthy "apt-mongodb"
wait_healthy "apt-postgres"
wait_healthy "apt-redis"

# ── Step 5: Verify Kafka topics ───────────────────────────────────────────────
echo ""
info "Verifying Kafka is accessible..."

docker exec apt-kafka kafka-topics \
    --bootstrap-server localhost:9092 \
    --create --if-not-exists \
    --topic network_traffic \
    --partitions 3 \
    --replication-factor 1 > /dev/null 2>&1

docker exec apt-kafka kafka-topics \
    --bootstrap-server localhost:9092 \
    --create --if-not-exists \
    --topic anomalies \
    --partitions 3 \
    --replication-factor 1 > /dev/null 2>&1

success "Kafka topics created: network_traffic, anomalies"

# ── Step 6: Verify PostgreSQL ─────────────────────────────────────────────────
echo ""
info "Verifying PostgreSQL connection..."
docker exec apt-postgres psql -U aptuser -d aptdb -c "SELECT 1" > /dev/null 2>&1
success "PostgreSQL accepting connections on port 5432"

# ── Step 7: Verify MongoDB ────────────────────────────────────────────────────
info "Verifying MongoDB connection..."
docker exec apt-mongodb mongosh --quiet \
    -u aptuser -p changeme --authenticationDatabase admin \
    --eval "db.adminCommand('ping')" > /dev/null 2>&1
success "MongoDB accepting connections on port 27017"

# ── Step 8: Verify Redis ──────────────────────────────────────────────────────
info "Verifying Redis connection..."
docker exec apt-redis redis-cli -a changeme ping > /dev/null 2>&1
success "Redis accepting connections on port 6379"

# ── Step 9: Compile the project ───────────────────────────────────────────────
echo ""
info "Compiling the project (first run downloads dependencies — ~3 min)..."
mvn compile -q
success "Compilation successful"

# ── Step 10: Run unit tests ───────────────────────────────────────────────────
echo ""
info "Running unit tests..."
mvn test -pl core,ingestion -q
success "All unit tests passed"

# ── Step 11: Start the app ────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}════════════════════════════════════════════${NC}"
echo -e "${GREEN}✅ Week 1 Infrastructure is READY!${NC}"
echo -e "${GREEN}════════════════════════════════════════════${NC}"
echo ""
echo "Services running:"
echo "  Kafka:     localhost:9092"
echo "  MongoDB:   localhost:27017"
echo "  PostgreSQL: localhost:5432"
echo "  Redis:     localhost:6379"
echo ""
echo "To start the Spring Boot application:"
echo ""
echo -e "  ${YELLOW}export \$(grep -v '^#' .env | xargs)${NC}"
echo -e "  ${YELLOW}mvn spring-boot:run -pl api -Dspring-boot.run.profiles=local${NC}"
echo ""
echo "Then verify it's working:"
echo -e "  ${YELLOW}curl http://localhost:8080/actuator/health${NC}"
echo ""
echo "To watch logs flowing into MongoDB in real time:"
echo -e "  ${YELLOW}docker exec -it apt-mongodb mongosh -u aptuser -p changeme --authenticationDatabase admin${NC}"
echo -e "  ${YELLOW}use aptdb${NC}"
echo -e "  ${YELLOW}db.network_events.watch()${NC}"
echo ""
echo "To stop everything:"
echo -e "  ${YELLOW}docker compose down${NC}"
echo ""

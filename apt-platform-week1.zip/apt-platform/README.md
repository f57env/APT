# 🛡️ APT Detection & Response Platform

A portfolio-grade, production-quality **Advanced Persistent Threat Detection Platform** built in Java — condensing a 6-month SDLC plan into a 4-week sprint.

## Architecture

```
                         ┌─────────────────────────────────────────────────┐
                         │                INGESTION LAYER                   │
  Simulated Network ──►  │  NetworkLogSimulator ──► Kafka ──► Consumer      │
  Logs (pcap/JSON)       │                         (topics:  ──► MongoDB    │
                         │                       network_     (raw logs)    │
                         └──────────────────────── traffic)────────────────┘
                                                       │
                         ┌─────────────────────────────▼───────────────────┐
                         │                DETECTION LAYER                   │
                         │  UEBA Profiler ──► Gaussian Scoring              │
                         │  Isolation Forest (DL4J)                         │
                         │  Autoencoder (DL4J) ──► Risk Score (0-100)       │
                         │  MITRE ATT&CK Mapper ──► PostgreSQL (alerts)     │
                         └────────────────────────┬────────────────────────┘
                                                  │
                         ┌────────────────────────▼────────────────────────┐
                         │              API + DASHBOARD LAYER               │
                         │  Spring Boot REST API ──► React Dashboard        │
                         │  WebSocket (real-time alerts) ──► D3.js topology │
                         │  Automated Response Engine                       │
                         │  JWT RBAC (ADMIN / SOC_ANALYST / VIEWER)         │
                         └─────────────────────────────────────────────────┘
```

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Language | Java 21 (Project Loom virtual threads) |
| Framework | Spring Boot 3.x |
| Stream Processing | Apache Kafka |
| ML Engine | Deeplearning4j (DL4J), Weka |
| Packet Capture | Pcap4j |
| Raw Log Storage | MongoDB 7 |
| Structured Storage | PostgreSQL 16 |
| Cache / State | Redis 7 |
| Frontend | React.js + D3.js + Chart.js |
| Security | JWT + RBAC + TOTP MFA |
| DevOps | Docker, GitHub Actions CI/CD |

## 4-Week Sprint Plan

| Week | Goal | Key Deliverable |
|------|------|-----------------|
| **1** | Architecture & Data Pipeline | `docker-compose up` → logs in MongoDB |
| **2** | ML Detection Engine | 1000 events → risk-scored MITRE-mapped alerts |
| **3** | REST API + Dashboard | Live SOC dashboard with WebSocket alerts |
| **4** | Testing & CI/CD | GitHub Actions pipeline, SpotBugs SAST, docs |

---

## 🚀 Quick Start (Week 1)

### Prerequisites

- Java 21 (Temurin): `sudo apt install temurin-21-jdk`
- Maven 3.9+: `sudo apt install maven`
- Docker Desktop (Windows) with WSL 2 backend enabled

### Setup

```bash
# 1. Clone and enter the project
git clone <your-repo> apt-platform && cd apt-platform

# 2. Run the Week 1 setup script (handles everything below automatically)
bash scripts/week1-run.sh
```

**Or manually:**

```bash
# Create your .env from the example
cp .env.example .env
# Edit .env with your own secrets

# Start all infrastructure
docker compose up -d

# Export env vars and start the app
export $(grep -v '^#' .env | xargs)
mvn spring-boot:run -pl api -Dspring-boot.run.profiles=local
```

### Verify it's working

```bash
# Health check
curl http://localhost:8080/actuator/health

# Watch events arriving in MongoDB in real time
docker exec -it apt-mongodb mongosh -u aptuser -p changeme \
  --authenticationDatabase admin \
  --eval "use aptdb; db.network_events.watch()"

# Watch Kafka topic (optional)
docker exec apt-kafka kafka-console-consumer \
  --bootstrap-server localhost:9092 \
  --topic network_traffic --from-beginning
```

### Default login

After the app starts, use these credentials to get a JWT:

```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin", "password": "ChangeMe123!"}'
```

> ⚠️ Change the admin password immediately after first login.

---

## Running Tests

```bash
# Unit tests only (fast, no Docker)
mvn test -pl core,ingestion

# All tests including integration tests (requires Docker)
mvn verify

# Tests with coverage report
mvn test jacoco:report
# Open: target/site/jacoco/index.html
```

---

## Project Structure

```
apt-platform/
├── core/           Shared domain models (NetworkEvent, Alert, EntityProfile …)
├── ingestion/      Kafka pipeline, log simulator, MongoDB persistence
├── detection/      ML engine (DL4J), UEBA profiler, MITRE mapper
├── api/            Spring Boot app, REST controllers, WebSocket, JWT security
├── response/       Automated response engine, audit log
├── docker/         Docker init scripts (Mongo, Postgres)
├── scripts/        Setup and utility scripts
└── frontend/       React dashboard (Week 3)
```

---

## Functional Requirements

| ID | Feature | Status |
|----|---------|--------|
| FR-1 | Multi-source log ingestion (Kafka) | ✅ Week 1 |
| FR-2 | UEBA behavioral profiling | 🔄 Week 2 |
| FR-3 | Anomaly detection (IF + Autoencoder) | 🔄 Week 2 |
| FR-4 | MITRE ATT&CK mapping | 🔄 Week 2 |
| FR-5 | Risk scoring engine (0–100) | 🔄 Week 2 |
| FR-6 | Automated response engine | 🔄 Week 3 |
| FR-7 | Visual analytics dashboard | 🔄 Week 3 |

---

## Security Notes

- All secrets are in `.env` (never committed — see `.gitignore`)
- Passwords hashed with BCrypt (strength 12)
- JWT tokens expire in 24h; refresh tokens in 7 days
- AES-256 encryption for config secrets via Jasypt (Week 4)
- TLS 1.3 for all API endpoints (Week 4)
- SAST with SpotBugs + FindSecBugs (Week 4)

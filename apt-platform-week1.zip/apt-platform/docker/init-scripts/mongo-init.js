// =============================================================================
// MongoDB initialization script
// Creates the aptdb database with required collections and indexes.
// Runs once on first container start.
// =============================================================================

db = db.getSiblingDB('aptdb');

// network_events collection — raw logs from the Kafka consumer
db.createCollection('network_events');
db.network_events.createIndex({ "userId": 1, "timestamp": -1 });   // UEBA queries
db.network_events.createIndex({ "timestamp": -1 });                 // Time-range scans
db.network_events.createIndex({ "srcIp": 1 });                      // IP lookups
db.network_events.createIndex({ "dstIp": 1 });

// TTL index: automatically delete raw logs older than 90 days
// This prevents unbounded disk growth in production
db.network_events.createIndex(
    { "timestamp": 1 },
    { expireAfterSeconds: 7776000, name: "ttl_90_days" }
);

print("✅ MongoDB aptdb initialized with network_events collection and indexes.");

-- =============================================================================
-- PostgreSQL initialization script
-- Runs once when the container is first created.
-- Flyway migrations (in api/src/main/resources/db/migration/) handle
-- table creation — this script just sets up extensions and permissions.
-- =============================================================================

-- Enable UUID generation (used for primary keys)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enable JSONB operators (used for SHAP drivers and baseline_data)
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- Grant all privileges on aptdb to our app user
GRANT ALL PRIVILEGES ON DATABASE aptdb TO aptuser;

-- Set default timezone to UTC — always store timestamps in UTC
ALTER DATABASE aptdb SET timezone TO 'UTC';

package com.apt.core.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

/**
 * NetworkEvent — the core unit of data flowing through the APT platform.
 *
 * This represents a single network or endpoint activity log entry.
 * It is:
 *   1. Produced to Kafka topic "network_traffic" by the log simulator
 *   2. Consumed, normalized, and stored in MongoDB by the ingestion consumer
 *   3. Read by the ML detection engine to build behavioral baselines
 *
 * Stored in MongoDB collection "network_events".
 * The @Indexed fields allow fast queries by userId and timestamp —
 * critical for building per-entity behavioral profiles.
 */
@Data                   // Lombok: generates getters, setters, equals, hashCode, toString
@Builder                // Lombok: NetworkEvent.builder().userId("alice").port(445).build()
@NoArgsConstructor      // Required by Jackson for deserialization
@AllArgsConstructor     // Required by @Builder
@Document(collection = "network_events")   // MongoDB collection name
public class NetworkEvent {

    @Id
    private String id;                  // MongoDB ObjectId (auto-generated)

    @Indexed
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant timestamp;          // When the event occurred

    @Indexed
    private String userId;              // The user or service account involved

    private String srcIp;               // Source IP address
    private String dstIp;               // Destination IP address
    private int    port;                // Destination port (445=SMB, 443=HTTPS, 22=SSH …)
    private long   bytes;               // Bytes transferred
    private String protocol;            // TCP / UDP / ICMP
    private String action;              // CONNECT, SEND, RECEIVE, FAILED_LOGIN …
    private String hostname;            // Source hostname (if available)
    private String processName;         // Process that initiated (e.g. "svchost.exe")
    private EventSource eventSource;    // Where this log came from

    /** Which system produced this event */
    public enum EventSource {
        NETWORK_TAP,      // Raw pcap / network traffic capture
        SYSMON,           // Windows Sysmon endpoint logs
        AUDITD,           // Linux auditd endpoint logs
        STIX_FEED,        // External threat intelligence
        SIMULATED         // Our test data generator
    }
}

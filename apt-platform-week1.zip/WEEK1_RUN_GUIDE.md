# Week 1 Run Guide — APT Detection Platform

## 1. Copy all project files into place

After downloading the zip, run this from your home directory in WSL:

```bash
# Move the extracted folder to your WSL home
mv /path/to/downloaded/apt-platform ~/apt-platform
cd ~/apt-platform
```

## 2. Set up environment variables

```bash
# Copy the example file and edit it
cp .env.example .env

# Generate a real JWT secret (required — must be base64-encoded, 64+ bytes)
openssl rand -base64 64 | tr -d '\n'
# → copy the output and paste as JWT_SECRET in .env

# Your .env should look like:
# POSTGRES_USER=aptuser
# POSTGRES_PASSWORD=ChangeMe_Postgres_2024!
# MONGO_USER=aptuser
# MONGO_PASSWORD=ChangeMe_Mongo_2024!
# REDIS_PASSWORD=ChangeMe_Redis_2024!
# JWT_SECRET=<your generated secret>
# JASYPT_ENCRYPTOR_PASSWORD=anypassword
```

## 3. Start the infrastructure stack

```bash
# Start Kafka, MongoDB, PostgreSQL, Redis in the background
docker compose up -d zookeeper kafka mongodb postgres redis

# Watch them become healthy (takes ~30 seconds)
docker compose ps

# You want to see "healthy" for all services:
# apt-zookeeper   running (healthy)
# apt-kafka       running (healthy)
# apt-mongodb     running (healthy)
# apt-postgres    running (healthy)
# apt-redis       running (healthy)
```

If Kafka shows "starting" for more than 60 seconds, check logs:
```bash
docker compose logs kafka
```

## 4. Verify Kafka is working

```bash
# List topics (should see none yet, but command should succeed)
docker exec apt-kafka kafka-topics --bootstrap-server localhost:9092 --list
```

## 5. Build the project

```bash
# From the apt-platform root directory
mvn clean compile -DskipTests

# Expected: BUILD SUCCESS
# This downloads all dependencies (~500MB first time, cached after)
# Subsequent builds: ~15 seconds
```

If you see dependency download errors, check your internet connection.
DL4J is a large download (~300MB) — be patient on first run.

## 6. Run the unit tests

```bash
# Run tests for the ingestion module (no Docker needed)
mvn test -pl ingestion

# Expected output:
# Tests run: 15, Failures: 0, Errors: 0, Skipped: 0
# BUILD SUCCESS
```

All ingestion tests run with embedded Kafka — no external services needed.

## 7. Start the Spring Boot application

```bash
# Run with the local profile (connects to Docker services on localhost ports)
mvn spring-boot:run -pl api -Dspring-boot.run.profiles=local \
  -Dspring-boot.run.jvmArguments="-DJWT_SECRET=${JWT_SECRET} \
  -DPOSTGRES_USER=${POSTGRES_USER} \
  -DPOSTGRES_PASSWORD=${POSTGRES_PASSWORD} \
  -DMONGO_USER=${MONGO_USER} \
  -DMONGO_PASSWORD=${MONGO_PASSWORD} \
  -DREDIS_PASSWORD=${REDIS_PASSWORD}"
```

Or, create a launch script for convenience:
```bash
cat > run-local.sh << 'EOF'
#!/bin/bash
set -a; source .env; set +a
mvn spring-boot:run -pl api \
  -Dspring-boot.run.profiles=local \
  -Dspring-boot.run.jvmArguments="\
    -DJWT_SECRET=${JWT_SECRET} \
    -DPOSTGRES_USER=${POSTGRES_USER} \
    -DPOSTGRES_PASSWORD=${POSTGRES_PASSWORD} \
    -DMONGO_USER=${MONGO_USER} \
    -DMONGO_PASSWORD=${MONGO_PASSWORD} \
    -DREDIS_PASSWORD=${REDIS_PASSWORD} \
    -DJASYPT_ENCRYPTOR_PASSWORD=${JASYPT_ENCRYPTOR_PASSWORD}"
EOF
chmod +x run-local.sh
./run-local.sh
```

## 8. Verify the deliverable — logs flowing into MongoDB

Watch for these log lines on startup:

```
INFO  c.a.i.simulator.NetworkLogSimulator - Produced event: user=alice.smith port=443 bytes=234521
INFO  c.a.i.consumer.NetworkEventConsumer - Persisted event abc123 for user alice.smith
INFO  c.a.i.consumer.NetworkEventConsumer - Persisted event def456 for user svc_backup
```

Then confirm data is in MongoDB:
```bash
# Open MongoDB shell
docker exec -it apt-mongodb mongosh \
  -u aptuser -p changeme --authenticationDatabase admin aptdb

# Run these queries inside mongosh:
db.network_events.countDocuments()
# → Should grow every second (10 events/sec default)

db.network_events.find().limit(3).pretty()
# → Shows normalized event documents

# Check for APT-pattern events (port 445 = SMB lateral movement)
db.network_events.find({ port: 445 }).count()

# Check for failed logins (brute force simulation)
db.network_events.find({ action: "FAILED_LOGIN" }).count()

# Exit mongosh
exit
```

## 9. Test the security endpoint

```bash
# The app should be running on port 8080
# Test that unauthenticated access is rejected:
curl -s http://localhost:8080/api/alerts | python3 -m json.tool
# → {"status":401,"error":"Unauthorized"}  ✅

# Test health endpoint (public):
curl -s http://localhost:8080/actuator/health | python3 -m json.tool
# → {"status":"UP","components":{"db":{"status":"UP"},...}}  ✅

# Login with the default admin user:
curl -s -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"ChangeMe123!"}' | python3 -m json.tool
# → {"token":"eyJ...","username":"admin","role":"ADMIN"}  ✅

# Use the token to access a protected endpoint:
TOKEN=$(curl -s -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"ChangeMe123!"}' | python3 -c "import sys,json; print(json.load(sys.stdin)['token'])")

curl -s http://localhost:8080/api/alerts \
  -H "Authorization: Bearer $TOKEN" | python3 -m json.tool
# → {"content":[],"totalElements":0,...}  ✅ (empty — alerts come in Week 2)
```

## 10. Check Swagger UI (bonus)

Open in your Windows browser:
```
http://localhost:8080/swagger-ui.html
```

All REST endpoints are documented here with live "Try it out" buttons.

---

## Troubleshooting

**"Connection refused" on port 9092:**
Kafka is still starting. Wait 30 seconds and retry.
Check: `docker compose logs kafka | tail -20`

**"Authentication failed" on MongoDB:**
The MONGO_USER/MONGO_PASSWORD in .env doesn't match what was set when
the container was first created. Run: `docker compose down -v` to wipe
volumes and restart fresh with correct credentials.

**"Flyway migration failed":**
Usually means PostgreSQL schema already has a version mismatch.
For dev, run: `docker compose down -v && docker compose up -d postgres`
to get a clean database, then restart the app.

**"No beans of type KafkaTemplate found":**
The ingestion module's KafkaConfig isn't being scanned.
Verify `@ComponentScan(basePackages = "com.apt")` is in AptPlatformApplication.

**DL4J download very slow:**
First run downloads native binaries for your platform (~300MB).
This is a one-time cost. Add `-Dmaven.repo.local=~/.m2/repository` to
reuse cached downloads across builds.

---

## Week 1 Checklist

- [ ] Docker Compose stack running (all 5 services healthy)
- [ ] `mvn clean compile` succeeds with BUILD SUCCESS
- [ ] `mvn test -pl ingestion` — all tests pass (15+ tests)
- [ ] App starts with `./run-local.sh`
- [ ] MongoDB shows growing event count via mongosh
- [ ] APT events (port 445, FAILED_LOGIN) visible in MongoDB
- [ ] `curl localhost:8080/api/alerts` returns 401 (security working)
- [ ] Login endpoint returns JWT token
- [ ] Authenticated request to /api/alerts returns 200

When all boxes are checked — you're ready for Week 2: the ML Detection Engine.
